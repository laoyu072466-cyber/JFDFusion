import matplotlib.pyplot as plt
import matplotlib.patches as patches


def create_freqmamba_diagram():
    """
    Creates and saves a block diagram of the FreqMambaLite module
    using matplotlib.
    """

    # --- Setup ---
    fig, ax = plt.subplots(figsize=(12, 10))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis('off')
    ax.set_title('FreqMambaLite Module Flow', fontsize=18, pad=20)

    # --- Styles ---
    module_style = dict(boxstyle='round,pad=0.7', fc='#F5F5F5', ec='black', alpha=1.0)
    io_style = dict(boxstyle='round,pad=0.7', fc='#A9D0F5', ec='black', alpha=1.0)
    gate_style = dict(boxstyle='round,pad=0.7', fc='#F3F781', ec='black', alpha=1.0)  # Yellow
    fusion_style = dict(boxstyle='round,pad=0.7', fc='#D8BFD8', ec='black', alpha=1.0)  # Thistle

    # --- Node Positions (x, y) ---
    pos = {
        'in': (50, 95),
        'norm': (50, 85),
        'gate': (25, 70),
        'cnn': (25, 55),
        'ss2d': (75, 70),
        'cat': (50, 40),
        'out': (50, 25)
    }

    # --- 1. Draw Nodes (as text boxes) ---
    nodes = {}
    nodes['in'] = ax.text(pos['in'][0], pos['in'][1], 'Input x\n[B, C, H, W]',
                          ha='center', va='center', bbox=io_style, fontsize=11)

    nodes['norm'] = ax.text(pos['norm'][0], pos['norm'][1], 'InstanceNorm2d',
                            ha='center', va='center', bbox=module_style, fontsize=11)

    nodes['gate'] = ax.text(pos['gate'][0], pos['gate'][1], 'FreqGate',
                            ha='center', va='center', bbox=gate_style, fontsize=11)

    nodes['cnn'] = ax.text(pos['cnn'][0], pos['cnn'][1], 'Branch A: CNN\n(3x3 Conv)',
                           ha='center', va='center', bbox=module_style, fontsize=11)

    nodes['ss2d'] = ax.text(pos['ss2d'][0], pos['ss2d'][1], 'Branch B: SS2D\n(Multi-Directional Scan)',
                            ha='center', va='center', bbox=module_style, fontsize=11)

    nodes['cat'] = ax.text(pos['cat'][0], pos['cat'][1], 'Concatenate\n(dim=1)',
                           ha='center', va='center', bbox=fusion_style, fontsize=11)

    # Output node
    io_style_out = io_style.copy()
    io_style_out['fc'] = '#A9F5A9'  # Light Green
    nodes['out'] = ax.text(pos['out'][0], pos['out'][1], 'Output fused\n[B, 2*C, H, W]',
                           ha='center', va='center', bbox=io_style_out, fontsize=11)

    # --- 2. Draw Arrows (Connections) ---
    annot_props = dict(
        xycoords='data',
        textcoords='data',
        arrowprops=dict(arrowstyle='-|>',
                        connectionstyle='arc3,rad=0',  # Straight line
                        color='black',
                        shrinkA=10,
                        shrinkB=10),
        horizontalalignment='center',
        verticalalignment='center'
    )

    # Main flow
    ax.annotate("", xy=pos['norm'], xytext=pos['in'], **annot_props)

    # Label for x_ln
    ax.text(pos['norm'][0], (pos['norm'][1] + pos['gate'][1] + 5) / 2,
            'x_ln', ha='center', va='center', fontsize=9,
            bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none', alpha=0.8))

    # Angled connections from norm
    annot_props_angle = annot_props.copy()
    annot_props_angle['arrowprops']['connectionstyle'] = 'arc3,rad=-0.3'
    ax.annotate("", xy=pos['gate'], xytext=pos['norm'], **annot_props_angle)

    annot_props_angle['arrowprops']['connectionstyle'] = 'arc3,rad=0.3'
    ax.annotate("", xy=pos['ss2d'], xytext=pos['norm'], **annot_props_angle)

    # Straight connection from FreqGate to CNN
    ax.annotate("", xy=pos['cnn'], xytext=pos['gate'], **annot_props)
    ax.text(pos['cnn'][0] + 8, (pos['cnn'][1] + pos['gate'][1]) / 2,
            'x_gated', ha='center', va='center', fontsize=9)

    # Angled connections to Concat
    annot_props_angle['arrowprops']['connectionstyle'] = 'arc3,rad=0.3'
    ax.annotate("", xy=pos['cat'], xytext=pos['cnn'], **annot_props_angle)
    ax.text((pos['cat'][0] + pos['cnn'][0]) / 2, (pos['cat'][1] + pos['cnn'][1]) / 2 + 5,
            'o2', ha='center', va='center', fontsize=9)

    annot_props_angle['arrowprops']['connectionstyle'] = 'arc3,rad=-0.3'
    ax.annotate("", xy=pos['cat'], xytext=pos['ss2d'], **annot_props_angle)
    ax.text((pos['cat'][0] + pos['ss2d'][0]) / 2, (pos['cat'][1] + pos['ss2d'][1]) / 2 + 5,
            'o3', ha='center', va='center', fontsize=9)

    # Final output connection
    ax.annotate("", xy=pos['out'], xytext=pos['cat'], **annot_props)

    # --- Save ---
    output_filename = 'freqmamba_module_flow.png'
    plt.savefig(output_filename, bbox_inches='tight', dpi=150)
    print(f"Module diagram saved as {output_filename}")


if __name__ == "__main__":
    create_freqmamba_diagram()