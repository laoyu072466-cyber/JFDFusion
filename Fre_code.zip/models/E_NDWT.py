import torch
import torch.nn as nn
import torch.nn.functional as F

class DWT2DPlus(nn.Module):
    """
    DWT2DPlus（无能量门控版）：
      在固定 Haar DWT 基础上，加入两点增强：
        1) learnable per-band mix（可学习子带混合，1x1 conv on 4 bands）
        2) adaptive soft-thresholding（每个子带可学习软阈值去噪）

    输入:  x  [B,1,H,W]
    输出:  y  [B,4,H,W]  （顺序仍为 [LL, LH, HL, HH]）
    """
    def __init__(self,
                 ksize: int = 2,
                 learn_mix: bool = True,
                 softshrink: bool = True):
        super().__init__()
        # --- 固定Haar核 ---
        h = 0.5 * torch.tensor([
            [[1,  1],
             [1,  1]],  # LL
            [[1,  1],
             [-1, -1]], # LH
            [[1, -1],
             [1, -1]],  # HL
            [[1, -1],
             [-1,  1]], # HH
        ], dtype=torch.float32)                     # [4,2,2]
        w = h.unsqueeze(1)                          # [4,1,2,2]
        self.conv = nn.Conv2d(1, 4, kernel_size=ksize, stride=1, padding=0, bias=False)
        with torch.no_grad():
            self.conv.weight.copy_(w)
        for p in self.conv.parameters():
            p.requires_grad = False                 # 保持Haar固定

        # --- 轻量增强组件 ---
        self.learn_mix   = learn_mix
        self.softshrink  = softshrink

        # 1) 子带混合（4->4，逐像素1x1，初始化为恒等）
        if self.learn_mix:
            self.mix = nn.Conv2d(4, 4, kernel_size=1, bias=False)
            with torch.no_grad():
                self.mix.weight.zero_()
                self.mix.bias.zero_()
                eye = torch.eye(4).view(4,4,1,1)
                self.mix.weight.copy_(eye)

        # 2) 自适应软阈值（每个子带一个可学习阈值，初始化很小）
        if self.softshrink:
            self.tau = nn.Parameter(torch.full((1,4,1,1), 1e-3))  # learnable thresholds
            self.bn  = nn.BatchNorm2d(4, affine=False)

    @staticmethod
    def _soft_shrink(x, tau):
        # Soft threshold: sign(x) * max(|x|-tau, 0)
        return torch.sign(x) * torch.relu(torch.abs(x) - tau)

    def forward(self, x):  # [B,1,H,W] -> [B,4,H,W]
        # SAME padding for k=2, s=1
        x = F.pad(x, (0,1,0,1))   # (left,right,top,bottom)
        y = self.conv(x)          # [B,4,H,W]

        # 2) 软阈值增强
        if self.softshrink:
            y = self.bn(y)
            y = self._soft_shrink(y, torch.clamp(self.tau, min=0.0))

        # 1) 子带混合
        if self.learn_mix:
            y = self.mix(y)

        return y
