from dataclasses import dataclass
# from itertools import pairwise
# 没有SSCM模块
import torch
import torch.nn.functional as F
from torch import nn, Tensor
from models.Edge import SCAM
from models.CMblock import SS2D1
from models.fusionlayer import MiEntropyFusion
@dataclass
class FuseInput:
    vi: Tensor
    ir: Tensor

@dataclass
class FuseOutput:
    fusion: Tensor
    ir_out: Tensor
    vi_out: Tensor


#解码器
class SimpleDecoder(nn.Module):
    def __init__(self, in_channels: int, mid_channels: list[int]):
        super().__init__()
        # 现在我们需要 3 个中间通道，length == 3
        assert len(mid_channels) == 3, "mid_channels list must contain exactly three elements."

        # 第1层：in_channels -> mid1
        self.conv1 = nn.Conv2d(in_channels,   mid_channels[0], kernel_size=3, padding=1)
        self.relu1 = nn.SiLU(inplace=True)

        # 第2层：mid1 -> mid2
        self.conv2 = nn.Conv2d(mid_channels[0], mid_channels[1], kernel_size=3, padding=1)
        self.relu2 = nn.ReLU(inplace=True)

        # 第3层：mid2 -> mid3
        self.conv3 = nn.Conv2d(mid_channels[1], mid_channels[2], kernel_size=3, padding=1)
        self.relu3 = nn.ReLU(inplace=True)

        # 第4层：mid3 -> 1
        self.conv4 = nn.Conv2d(mid_channels[2], 1,             kernel_size=3, padding=1)
        self.tanh  = nn.Tanh()

    def forward(self, x):
        x = self.relu1(self.conv1(x))  # B, mid1, H, W
        x = self.relu2(self.conv2(x))  # B, mid2, H, W
        x = self.relu3(self.conv3(x))  # B, mid3, H, W
        x = self.tanh (self.conv4(x))  # B,    1, H, W
        return x

    
#整体模型
class DBTFuse2(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        num_features: int,

        patch_size: 16
    ):
        super().__init__()
    
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.edge=SCAM(in_channels=32)

 
        self.Mam = SS2D1(d_model=32)
        # print(f"self.encode_comm.out_channels: {self.encode_comm.out_channels}")
        self.conv = nn.Conv2d(2, 4, kernel_size=3, stride=1, padding='same', dilation=1, groups=in_channels, bias=True, padding_mode='zeros')
        self.act = nn.LeakyReLU(negative_slope=0.01)
        self.ln_vi = nn.InstanceNorm2d(4)
        self.ln_ir = nn.InstanceNorm2d(4)

        self.conv_ir = nn.Conv2d(in_channels, 32, kernel_size=3, stride=1, padding=1)
        decoder_channels = [num_features + num_features, 32, 16,8] # 解码器层的通道数
        self.decoder_vi = SimpleDecoder(32, decoder_channels[1:])
        self.decoder_ir = SimpleDecoder(32, decoder_channels[1:])
        self.decoder_fuse = SimpleDecoder(64, decoder_channels[out_channels:])
        self.fusion_strategy = MiEntropyFusion()
        # print("卷积核",(self.encode_ir.out_channels))

        self.proj_out = nn.Tanh()


    def forward(self, inputs: FuseInput):
        # print("输入")
        # print((inputs.vi).shape)
        # print((inputs.ir).shape)
        # print("ir1M之前的输入",inputs.vi.shape)
        # print("ir1M之前的输入",inputs.ir.shape)
        ir_N1 = self.conv_ir(inputs.ir)  # 这里将 inputs.ir 的通道数卷积为32
        # ir_N = self.edge(ir_N1)
        
        vi_N1 = self.conv_ir(inputs.vi)  # 这里将 inputs.ir 的通道数卷积为32
        # print("vi_N1",vi_N1.shape)
        vi_N=self.edge(vi_N1)
        ir_N=self.edge(ir_N1)
        # print("输入vi")
        # print(vi_N.shape)
        # print("输入IR",ir_N.shape)
        # vi_E = vi_E.permute(0, 3, 2, 1)
        ##经过EFE.py
        # ir_E = ir_E.permute(0, 3, 2, 1)
        # print("ir2M之前的输入",ir_N.shape)
        # print("ir2M之前的输入",vi_N.shape)
        ##经过CMBlock.py
        # print("VI_N",vi_N.shape)
        
      
        # print("ir_s",ir_S.shape)
    
        # ir_S = ir_S+ir_N1
        # print("vi_N",vi_N.shape)
        vi_M = self.Mam(vi_N)
        ir_M = self.Mam(ir_N)

        # vi_M = vi_M.permute(0,3,1,2).contiguous()  # [B, H, W, C1]
        # ir_M = ir_M.permute(0,3,1,2).contiguous()  # [B, H, W, C2]
        # print("Vi_M",vi_M.shape)
        # print(ir_M.shape)
        merged, w1, w2 = self.fusion_strategy(ir_M,vi_M)
                # print("w_vi",w_vi)
        # fusion = w_ir+w_vi
    
        # print("fusion",merged.shape)
        # print("形状",fused.shape)
        # merged = self.fusion_strategy(fused)
        # print("merged",merged.shape)
        # print("ir",ir_M.shape)
        r_ir = self.proj_out(self.decoder_ir(ir_N))
        r_vi = self.proj_out(self.decoder_vi(vi_N))
        fusion = self.proj_out(self.decoder_fuse(merged))
        # fusion = torch.nn.functional.interpolate(fusion, size=(224, 224), mode='bilinear', align_corners=False)
        # fuse = self.proj_out(self.decoder_fuse(comm))
        # print("fuse",fusion.shape)
        # print('r_vi',r_vi.shape)
        # print(f"Output min: {fusion.min().item()}, max: {fusion.max().item()}, mean: {fusion.mean().item()}")
        return FuseOutput(
            fusion=fusion.clamp(-1.0, 1.0),
            vi_out=r_vi.clamp(-1.0, 1.0),
            ir_out=r_ir.clamp(-1.0, 1.0)
        )

    def frozen(self, *__names: str):
        for name, param in self.named_parameters():
            for _name in __names:
                if _name in name:
                    param.requires_grad = False
                    print('frozen layer:', name)

if __name__ == '__main__':
    model = DBTFuse2(
        in_channels=1,
        out_channels=1,
        num_features=48,
        patch_size= 16

    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    vi = torch.randn(1,1, 224, 224).to(device)  # input VIS,batchsize=3,channel=3
    ir = torch.randn(1, 1,224, 224).to(device)  # input IR

    fuse_input = FuseInput(vi=vi, ir=ir)

    with torch.no_grad():  
        fuse_output = model(fuse_input)


    print(f"Fusion output shape: {fuse_output.fusion.shape}")
