import torch
from torch import Tensor, nn
from typing import List
import torchvision.transforms as transforms
from PIL import Image
from torch import nn
from torch.nn import init
import math
import numpy as np
from models.FFST._shearletTransformSpect import shearletTransformSpect
from models.FFST._inverseShearletTransformSpect import inverseShearletTransformSpect
import torch.nn.functional as F
# 获取频率选择的索引
def get_freq_indices(method):# 确保方法在预定义的选择里
    assert method in ['top1', 'top2', 'top4', 'top8', 'top16', 'top32',
                      'bot1', 'bot2', 'bot4', 'bot8', 'bot16', 'bot32',
                      'low1', 'low2', 'low4', 'low8', 'low16', 'low32']
    num_freq = int(method[3:]) # 从方法名获取频率数量
    # 根据不同的选择方法获取频率的x和y索引
    if 'top' in method:  # 高频索引
        all_top_indices_x = [0, 0, 6, 0, 0, 1, 1, 4, 5, 1, 3, 0, 0,
                             0, 3, 2, 4, 6, 3, 5, 5, 2, 6, 5, 5, 3, 3, 4, 2, 2, 6, 1]
        all_top_indices_y = [0, 1, 0, 5, 2, 0, 2, 0, 0, 6, 0, 4, 6,
                             3, 5, 2, 6, 3, 3, 3, 5, 1, 1, 2, 4, 2, 1, 1, 3, 0, 5, 3]
        mapper_x = all_top_indices_x[:num_freq]
        mapper_y = all_top_indices_y[:num_freq]
    elif 'low' in method:# 低频索引
        all_low_indices_x = [0, 0, 1, 1, 0, 2, 2, 1, 2, 0, 3, 4, 0,
                             1, 3, 0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4]
        all_low_indices_y = [0, 1, 0, 1, 2, 0, 1, 2, 2, 3, 0, 0, 4,
                             3, 1, 5, 4, 3, 2, 1, 0, 6, 5, 4, 3, 2, 1, 0, 6, 5, 4, 3]
        mapper_x = all_low_indices_x[:num_freq]
        mapper_y = all_low_indices_y[:num_freq]
    elif 'bot' in method:# 底部频率索引
        all_bot_indices_x = [6, 1, 3, 3, 2, 4, 1, 2, 4, 4, 5, 1, 4,
                             6, 2, 5, 6, 1, 6, 2, 2, 4, 3, 3, 5, 5, 6, 2, 5, 5, 3, 6]
        all_bot_indices_y = [6, 4, 4, 6, 6, 3, 1, 4, 4, 5, 6, 5, 2,
                             2, 5, 1, 4, 3, 5, 0, 3, 1, 1, 2, 4, 2, 1, 1, 5, 3, 3, 3]
        mapper_x = all_bot_indices_x[:num_freq]
        mapper_y = all_bot_indices_y[:num_freq]
    else:
        raise NotImplementedError
    return mapper_x, mapper_y

# 多频谱注意力层
class MultiSpectralAttentionLayer(nn.Module):
    def __init__(self, channel, dct_h, dct_w, reduction=16, freq_sel_method='top16'):
        super(MultiSpectralAttentionLayer, self).__init__()
        self.reduction = reduction# 降维比例
        self.dct_h = dct_h# DCT变换的高度
        self.dct_w = dct_w# DCT变换的宽度

        mapper_x, mapper_y = get_freq_indices(freq_sel_method)# 获取频率选择的索引
        self.num_split = len(mapper_x)# 分割的数量
        mapper_x = [temp_x * (dct_h // 7) for temp_x in mapper_x]# 调整索引以适应DCT高度
        mapper_y = [temp_y * (dct_w // 7) for temp_y in mapper_y]# 调整索引以适应DCT宽度
      

        self.dct_layer = MultiSpectralDCTLayer(
            dct_h, dct_w, mapper_x, mapper_y, channel)
        # print("channel",channel,reduction)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )
        # print("宽度和高度",self.dct_w,self.dct_h)
        self.avgpool = nn.AdaptiveAvgPool2d((self.dct_h, self.dct_w))

    def forward(self, x):
        # print(x.shape)
        n, c, h, w = x.shape # 获取输入形状
        x_pooled = x
        if h != self.dct_h or w != self.dct_w: 
            x_pooled = self.avgpool(x)# 如果输入尺寸不匹配，进行池化
        # print("x在批破哦",x_pooled.shape)
        y = self.dct_layer(x_pooled)
        # print("y在pool",y.shape)
        y = y.float()
        # print("y.float",y.shape)
        y_c = y.shape[1]
        # print("我要找yc",y_c)
        # print(x.shape)
        x_in_channels = x.shape[1]
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        conv = nn.Conv2d(in_channels=x_in_channels, out_channels=y_c, kernel_size=1).to(device)
        # print("inchannels",x_in_channels,y_c)
        x=x.to(device)
        x = conv(x)
        # print("y的形状")
        # print(y.shape)
        # print("x的device,",x.device)
        # print(y.device)
        y = self.fc(y).view(n, y_c, 1, 1)
        return x * y.expand_as(x)

 # 实现多频谱DCT层
class MultiSpectralDCTLayer(nn.Module):
   

    def __init__(self, height, width, mapper_x, mapper_y, channel):
        super(MultiSpectralDCTLayer, self).__init__()

        assert len(mapper_x) == len(mapper_y)  # 确保x和y索引的长度相同
        assert channel % len(mapper_x) == 0 # 确保通道数可以被频率数量整除

        self.num_freq = len(mapper_x) # 频率数量

    # 获取DCT滤波器
        self.weight = self.get_dct_filter(
            height, width, mapper_x, mapper_y, channel)

    def forward(self, x):
        assert len(x.shape) == 4, 'x must been 4 dimensions, but got ' + \
                                  str(len(x.shape))
        # n, c, h, w = x.shape

        weight = self.weight.unsqueeze(0)
        #调整x的形状
        in_channels = x.shape[1] 
        out_channels = weight.shape[1]
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1).to(device)
        x=x.to(device)
        x = conv(x)
        
        weight=weight.to(device)
        x = x * weight # 将DCT滤波器应用于输入
        result = torch.sum(torch.sum(x, dim=2), dim=2) # 求和以获取最终结果
        return result

    def build_filter(self, pos, freq, POS):# 构建DCT滤波器的辅助函数，计算DCT基函数值
        result = math.cos(math.pi * freq * (pos + 0.5) / POS) / math.sqrt(POS)
        if freq == 0:
            return result
        else:
            return result * math.sqrt(2)
# 生成DCT滤波器，mapper_x和mapper_y定义了选中的DCT频率
    def get_dct_filter(self, tile_size_x, tile_size_y, mapper_x, mapper_y, channel):
        dct_filter = torch.zeros((channel, tile_size_x, tile_size_y))# 计算每个频率对应的通道数

        c_part = channel // len(mapper_x)

        for i, (u_x, v_y) in enumerate(zip(mapper_x, mapper_y)):
            for t_x in range(tile_size_x):
                for t_y in range(tile_size_y):
                    # 对每个位置应用build_filter函数，构建DCT滤波器
                    dct_filter[i * c_part: (i + 1) * c_part, t_x, t_y] = self.build_filter(
                        t_x, u_x, tile_size_x) * self.build_filter(t_y, v_y, tile_size_y)

        return dct_filter


# —— 测试 ——  
class SFBlock(nn.Module):
    def __init__(
        self,
        in_channels=1,
        out_channels=16,
        dct_h=128,
        dct_w=120,
        reduction=16,
        freq_sel_method="top2",
        num_detail_layers=3
    ) -> None:
        super().__init__()
        # 1x1 时域通道映射
        self.input_conv = nn.LazyConv2d(out_channels, kernel_size=1, bias=False)
        feature_channels = out_channels

        # F F S T 多频谱注意力
        mapper_x, _ = get_freq_indices(freq_sel_method)
        num_freq = len(mapper_x)
        total_ch = feature_channels * num_freq
        self.msa = MultiSpectralAttentionLayer(
            channel=total_ch,
            dct_h=dct_h,
            dct_w=dct_w,
            reduction=reduction,
            freq_sel_method=freq_sel_method
        )
        self.act = nn.LeakyReLU(inplace=True)
        self.norm = nn.InstanceNorm2d(feature_channels)
        # 频域 Detail（可选留空或移除）
        # self.detail_freq = DetailFeatureExtraction(num_layers=num_detail_layers, in_channels=total_ch)

        # 时域 DetailFeature


    def forward(self, x: Tensor) -> Tensor:
        # 时域 1×1 映射 + INN + 激活
        out = self.input_conv(x)
        # out = self.norm(out)
        # out = self.act(out)

        bs, ch, H, W = out.shape
        outs = []
        Psi_saved = None
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        for b in range(bs):
            coef_list = []
            for c in range(ch):
                Xi = out[b, c].detach().cpu().numpy()
                ST_c, Psi = shearletTransformSpect(Xi, realCoefficients=True)
                coef_list.append(ST_c)
                if Psi_saved is None:
                    Psi_saved = Psi

            # 频域拼接通道用于注意力
            ST_stack = np.stack(coef_list, axis=0)
            freq = torch.from_numpy(ST_stack)
            freq = (freq.permute(3,0,1,2)
                    .reshape(1, -1, H, W)
                    .to(x.device).float())

            # 频域注意力
            # self.msa=self.msa.to(device)
            freq = self.msa(freq)
            a=freq.shape[1]
            # print("a",freq.shape[1])
            # (移除频域 detail)
            # freq = self.detail_freq(freq)

            # 1x1 映射回时域通道数 并逆变换
            # print("freq之前",freq.shape,Psi_saved.shape)
            conv = nn.Conv2d(freq.shape[1], Psi_saved.shape[2], 1, bias=False).to(x.device)
            # print("freq",freq.device)
            freq2= conv(freq)
            # print("freq之后",freq.shape)
            freq = freq2.squeeze(0).permute(1,2,0).cpu().detach().numpy()
            rec = inverseShearletTransformSpect(freq, Psi_saved)
            rec_torch = torch.from_numpy(rec).to(x.device).unsqueeze(0)
            rec_torch = rec_torch.permute(0, 3, 1, 2).float()
            # print("rec_torch",rec_torch.shape)
            
            conv1 = nn.Conv2d(rec_torch.shape[1], a, 1, bias=False).to(x.device)
            # 时域 Detail
            rec_torch=conv1(rec_torch).to(x.device)
            # print("rec_torch最后",rec_torch.shape)
            # rec_torch=rec_torch.permute(0, 2, 3, 1)

            outs.append(rec_torch.squeeze(0))

        # 重建回 [N,C,H,W]
        out = torch.stack(outs, dim=0)
        # 最后 normalization + activation
        out = self.norm(out)
        out = F.relu(out)
        return out

if __name__ == "__main__":

    input_tensor = torch.rand(1, 16, 256, 256)

    # 初始化 block，各个参数需与你的网络定义保持一致
    model = SFBlock(
        in_channels=16,
        out_channels=16,
        dct_h=128,
        dct_w=120,
        reduction=16,
        freq_sel_method="top2",
        num_detail_layers=3
    )

    model.eval()
    with torch.no_grad():
        output = model(input_tensor)

    print("Output shape:", output.shape)  # 应该输出 torch.Size([1, 32, 128, 120])