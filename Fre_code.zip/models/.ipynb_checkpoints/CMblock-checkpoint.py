import torch
import torch.nn as nn
import torch.utils.checkpoint as checkpoint
import math
import torch.nn.functional as F
from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, selective_scan_ref
from einops import rearrange, repeat
from torch.nn import init
# from base import DWConv2d
import time
from functools import partial
from typing import Optional, Callable
import numpy as np
from typing import Callable
from functools import partial
# import timm
from timm.layers import DropPath, to_2tuple, trunc_normal_
try:
    from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, selective_scan_ref
except:
    pass

# 2.   **Model**
#CoordAtt Block

class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)  # 使用ReLU6实现

    def forward(self, x):
        return self.relu(x + 3) / 6  # 公式为ReLU6(x+3)/6，模拟Sigmoid激活函数

# 定义h_swish激活函数，这是基于h_sigmoid的Swish函数变体
class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)  # 使用上面定义的h_sigmoid

    def forward(self, x):
        return x * self.sigmoid(x)  # 公式为x * h_sigmoid(x)

# 定义Coordinate Attention模块
class CoordAtt(nn.Module):
    def __init__(self, inp, oup, reduction=32):
        super(CoordAtt, self).__init__()
        # 定义水平和垂直方向的自适应平均池化
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))  # 水平方向
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))  # 垂直方向

        mip = max(8, inp // reduction)  # 计算中间层的通道数

        # 1x1卷积用于降维
        self.conv1 = nn.Conv2d(inp * 2, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)  # 批归一化
        self.act = h_swish()  # 激活函数

        # 两个1x1卷积，分别对应水平和垂直方向
        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x  # 保存输入作为残差连接

        n, c, h, w = x.size()  # 获取输入的尺寸
        x_h = self.pool_h(x)  # 水平方向池化
        x_w = self.pool_w(x).permute(0, 1, 3, 2)  # 垂直方向池化并交换维度以适应拼接

        y = torch.cat([x_h, x_w], dim=2)  # 拼接水平和垂直方向的特征
        y = self.conv1(y)  # 通过1x1卷积降维
        y = self.bn1(y)  # 批归一化
        y = self.act(y)  # 激活函数

        x_h, x_w = torch.split(y, [h, w], dim=2)  # 将特征拆分回水平和垂直方向
        x_w = x_w.permute(0, 1, 3, 2)  # 恢复x_w的原始维度

        a_h = self.conv_h(x_h).sigmoid()  # 通过1x1卷积并应用Sigmoid获取水平方向的注意力权重
        a_w = self.conv_w(x_w).sigmoid()  # 通过1x1卷积并应用Sigmoid获取垂直方向的注意力权重

        out = identity * a_w * a_h  # 应用注意力权重到输入特征，并与残差连接相乘

        return out  # 返回输出


## **SEnet**
# class ECAAttention(nn.Module):

#     def __init__(self, kernel_size=3):
#         super().__init__()
#         self.gap = nn.AdaptiveAvgPool2d(1)  
#         self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2)
#         self.sigmoid = nn.Sigmoid()  # Sigmoid

#     # 权重初始化方法
#     def init_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Conv2d):
#                 init.kaiming_normal_(m.weight, mode='fan_out')  
#                 if m.bias is not None:
#                     init.constant_(m.bias, 0)  
#             elif isinstance(m, nn.BatchNorm2d):
#                 init.constant_(m.weight, 1)  
#                 init.constant_(m.bias, 0)  
#             elif isinstance(m, nn.Linear):
#                 init.normal_(m.weight, std=0.001)  
#                 if m.bias is not None:
#                     init.constant_(m.bias, 0)  #


#     def forward(self, x):
#         y = self.gap(x)  
#         y = y.squeeze(-1).permute(0, 2, 1)  
#         y = self.conv(y)  
#         y = self.sigmoid(y)  
#         y = y.permute(0, 2, 1).unsqueeze(-1)  
#         return x * y.expand_as(x)  




## **VSS Block**

class SS2D1(nn.Module):
    def __init__(
        self,
        d_model,
        d_state=16,
        # d_state="auto", # 20240109
        d_conv=3,
        expand=2,
        dt_rank="auto",
        dt_min=0.001,
        dt_max=0.1,
        dt_init="random",
        dt_scale=1.0,
        dt_init_floor=1e-4,
        dropout=0.,
        conv_bias=True,
        bias=False,
        device=None,
        dtype=None,
        **kwargs,
    ):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()
        self.d_model = d_model
        self.ECA_attention = CoordAtt(d_model,d_model)
        self.d_state = d_state
        # self.d_state = math.ceil(self.d_model / 6) if d_state == "auto" else d_model # 20240109
        self.d_conv = d_conv
        self.expand = expand
        self.d_inner = int(self.expand * self.d_model)
        self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank
        # print("模型")
        # print(self.d_model)
        self.in_proj = nn.Linear(self.d_model, self.d_inner * 2, bias=bias, **factory_kwargs)
        self.conv2d = nn.Conv2d(
            in_channels=self.d_inner,
            out_channels=self.d_inner,
            groups=self.d_inner,
            bias=conv_bias,
            kernel_size=d_conv,
            padding=(d_conv - 1) // 2,
            **factory_kwargs,
        )
        self.act = nn.SiLU()

        self.x_proj = (
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
        )
        self.x_proj_weight = nn.Parameter(torch.stack([t.weight for t in self.x_proj], dim=0)) # (K=4, N, inner)
        del self.x_proj

        self.dt_projs = (
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor, **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor, **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor, **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor, **factory_kwargs),
        )
        self.dt_projs_weight = nn.Parameter(torch.stack([t.weight for t in self.dt_projs], dim=0)) # (K=4, inner, rank)
        self.dt_projs_bias = nn.Parameter(torch.stack([t.bias for t in self.dt_projs], dim=0)) # (K=4, inner)
        del self.dt_projs

        self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=4, merge=True) # (K=4, D, N)
        self.Ds = self.D_init(self.d_inner, copies=4, merge=True) # (K=4, D, N)

        # self.selective_scan = selective_scan_fn
        self.forward_core = self.forward_corev0

        self.out_norm = nn.LayerNorm(self.d_inner)
        self.out_proj = nn.Linear(self.d_inner, self.d_model, bias=bias, **factory_kwargs)
        self.dropout = nn.Dropout(dropout) if dropout > 0. else None

    @staticmethod
    def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4, **factory_kwargs):
        dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

        # Initialize special dt projection to preserve variance at initialization
        dt_init_std = dt_rank**-0.5 * dt_scale
        if dt_init == "constant":
            nn.init.constant_(dt_proj.weight, dt_init_std)
        elif dt_init == "random":
            nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
        else:
            raise NotImplementedError

        # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
        dt = torch.exp(
            torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
            + math.log(dt_min)
        ).clamp(min=dt_init_floor)
        # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
        inv_dt = dt + torch.log(-torch.expm1(-dt))
        with torch.no_grad():
            dt_proj.bias.copy_(inv_dt)
        # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
        dt_proj.bias._no_reinit = True

        return dt_proj

    @staticmethod
    def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
        # S4D real initialization
        A = repeat(
            torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
            "n -> d n",
            d=d_inner,
        ).contiguous()
        A_log = torch.log(A)  # Keep A_log in fp32
        if copies > 1:
            A_log = repeat(A_log, "d n -> r d n", r=copies)
            if merge:
                A_log = A_log.flatten(0, 1)
        A_log = nn.Parameter(A_log)
        A_log._no_weight_decay = True
        return A_log

    @staticmethod
    def D_init(d_inner, copies=1, device=None, merge=True):
        # D "skip" parameter
        D = torch.ones(d_inner, device=device)
        if copies > 1:
            D = repeat(D, "n1 -> r n1", r=copies)
            if merge:
                D = D.flatten(0, 1)
        D = nn.Parameter(D)  # Keep in fp32
        D._no_weight_decay = True
        return D

    def forward_corev0(self, x: torch.Tensor):
        self.selective_scan = selective_scan_fn

        B, C, H, W = x.shape
        L = H * W
        K = 4

        x_hwwh = torch.stack([x.view(B, -1, L), torch.transpose(x, dim0=2, dim1=3).contiguous().view(B, -1, L)], dim=1).view(B, 2, -1, L)
        xs = torch.cat([x_hwwh, torch.flip(x_hwwh, dims=[-1])], dim=1) # (b, k, d, l)

        x_dbl = torch.einsum("b k d l, k c d -> b k c l", xs.view(B, K, -1, L), self.x_proj_weight)
        # x_dbl = x_dbl + self.x_proj_bias.view(1, K, -1, 1)
        dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=2)
        dts = torch.einsum("b k r l, k d r -> b k d l", dts.view(B, K, -1, L), self.dt_projs_weight)
        # dts = dts + self.dt_projs_bias.view(1, K, -1, 1)

        xs = xs.float().view(B, -1, L) # (b, k * d, l)
        dts = dts.contiguous().float().view(B, -1, L) # (b, k * d, l)
        Bs = Bs.float().view(B, K, -1, L) # (b, k, d_state, l)
        Cs = Cs.float().view(B, K, -1, L) # (b, k, d_state, l)
        Ds = self.Ds.float().view(-1) # (k * d)
        As = -torch.exp(self.A_logs.float()).view(-1, self.d_state)  # (k * d, d_state)
        dt_projs_bias = self.dt_projs_bias.float().view(-1) # (k * d)

        out_y = self.selective_scan(
            xs, dts,
            As, Bs, Cs, Ds, z=None,
            delta_bias=dt_projs_bias,
            delta_softplus=True,
            return_last_state=False,
        ).view(B, K, -1, L)
        assert out_y.dtype == torch.float

        inv_y = torch.flip(out_y[:, 2:4], dims=[-1]).view(B, 2, -1, L)
        wh_y = torch.transpose(out_y[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
        invwh_y = torch.transpose(inv_y[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)

        return out_y[:, 0], inv_y[:, 0], wh_y, invwh_y

    # an alternative to forward_corev1
    def forward_corev1(self, x: torch.Tensor):
        self.selective_scan = selective_scan_fn

        B, C, H, W = x.shape
        L = H * W
        K = 4

        x_hwwh = torch.stack([x.view(B, -1, L), torch.transpose(x, dim0=2, dim1=3).contiguous().view(B, -1, L)], dim=1).view(B, 2, -1, L)
        xs = torch.cat([x_hwwh, torch.flip(x_hwwh, dims=[-1])], dim=1) # (b, k, d, l)

        x_dbl = torch.einsum("b k d l, k c d -> b k c l", xs.view(B, K, -1, L), self.x_proj_weight)
        # x_dbl = x_dbl + self.x_proj_bias.view(1, K, -1, 1)
        dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=2)
        dts = torch.einsum("b k r l, k d r -> b k d l", dts.view(B, K, -1, L), self.dt_projs_weight)
        # dts = dts + self.dt_projs_bias.view(1, K, -1, 1)

        xs = xs.float().view(B, -1, L) # (b, k * d, l)
        dts = dts.contiguous().float().view(B, -1, L) # (b, k * d, l)
        Bs = Bs.float().view(B, K, -1, L) # (b, k, d_state, l)
        Cs = Cs.float().view(B, K, -1, L) # (b, k, d_state, l)
        Ds = self.Ds.float().view(-1) # (k * d)
        As = -torch.exp(self.A_logs.float()).view(-1, self.d_state)  # (k * d, d_state)
        dt_projs_bias = self.dt_projs_bias.float().view(-1) # (k * d)

        out_y = self.selective_scan(
            xs, dts,
            As, Bs, Cs, Ds,
            delta_bias=dt_projs_bias,
            delta_softplus=True,
        ).view(B, K, -1, L)
        assert out_y.dtype == torch.float

        inv_y = torch.flip(out_y[:, 2:4], dims=[-1]).view(B, 2, -1, L)
        wh_y = torch.transpose(out_y[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
        invwh_y = torch.transpose(inv_y[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)

        return out_y[:, 0], inv_y[:, 0], wh_y, invwh_y

    def forward(self, x: torch.Tensor, **kwargs):
        # print("x1",x.shape)
        B, H, W, C = x.shape
        # print("xbeforeINpro",x.shape)
        xz = self.in_proj(x)
        # print("xz",xz.shape)
        x, z = xz.chunk(2, dim=-1) # (b, h, w, d)，分割成两个部分
        # print("xz",x.shape)
        x = x.permute(0, 3, 1, 2).contiguous()
        x1=self.conv2d(x)
        # print("x1",x1.shape)
        x = self.act(x1) # (b, d, h, w),通过激活函数Silu
        # print("afterSILU",x.shape)
        y1, y2, y3, y4 = self.forward_core(x) #通过SS2D模块
        assert y1.dtype == torch.float32
        y = y1 + y2 + y3 + y4
        y = torch.transpose(y, dim0=1, dim1=2).contiguous().view(B, H, W, -1)
        # print("before_out_normal",y.shape)
        y = self.out_norm(y)
        # print("out_normal",y.shape)

        z = z.permute(0, 3, 1, 2).contiguous()
        # print("z",z.shape)
        z = self.ECA_attention(z)
        # print(z.shape)
        z = z.permute(0, 2, 3, 1).contiguous()#通过注意力机制和激活函数
        # print("after_atten_z",z.shape)
        y = y * F.silu(z)#进行哈达玛乘积
        # print("y",y.shape)
        out = self.out_proj(y)
        # print("after_proout",out.shape)
        x1_skip = x1.permute(0, 2, 3, 1).contiguous().view(B, H, W, -1)
        # print("x1_skip",x1_skip.shape)
        out = out + x1_skip
        # print("out",out.shape)
        if self.dropout is not None:
            out = self.dropout(out)
        return out


class VSSBlock(nn.Module):
    def __init__(
        self,
        hidden_dim: int = 0,
        drop_path: float = 0,
        attn_drop_rate: float = 0,
        d_state: int = 16,
        **kwargs,
    ):
        super().__init__()
        self.ln_1 = nn.InstanceNorm2d(hidden_dim)
        self.self_attention = SS2D1(d_model=hidden_dim, dropout=attn_drop_rate, d_state=d_state, **kwargs)
        self.drop_path = DropPath(drop_path)
        self.conv_layer = nn.Conv2d(in_channels=1, out_channels=2, kernel_size=1) 
    def forward(self, input: torch.Tensor):
        # print("x_vSS_x",input.shape)
        a=self.ln_1(input)
        # print("X_VSSa",a.shape)
        b=self.self_attention(self.ln_1(input))
        # print("X_VSSb",b.shape)
        c=self.drop_path(self.self_attention(self.ln_1(input)))
        # print("X_VSSc",c.shape)
        input=input.permute(0, 3, 1, 2) 
        # print(input.shape)
        # conv_layer = nn.Conv2d(in_channels=1, out_channels=2, kernel_size=1)

        input1 = self.conv_layer(input)  # 使用定义好的卷积层
        input1 = input1.permute(0, 2, 3, 1)
        # print("卷积后的维度", input1.shape)
        x = input1+ c
        # print("X_VSS",x.shape)
        return x

## **Model**

### Encoder Block

class CMambaBlock(nn.Module):
    def __init__(self, in_c, out_c,
                 norm_layer: Callable[..., torch.nn.Module] = partial(nn.LayerNorm, eps=1e-6)):
        super().__init__()
        self.in_c = in_c
        self.out_channels = out_c or in_c
        self.act = nn.LeakyReLU(negative_slope=0.01)

        # 定义卷积层
        self.conv = nn.Conv2d(in_c, in_c, kernel_size=3, stride=1, padding='same', dilation=1, groups=in_c, bias=True, padding_mode='zeros')
        self.ins_norm = nn.InstanceNorm2d(in_c)
        self.block = VSSBlock(hidden_dim=in_c)
        
        # 新增卷积层，将通道数增加一倍
        
        self.scale = nn.Parameter(torch.ones(1))

    def forward(self, x):
        skip = x
        # print("CM_x",x.shape)
        x = self.conv(x)
        # print("CM_x",x.shape)
        x = x.permute(0, 2, 3, 1)
        # print("after_permute",x.shape)
        x = self.block(x)
        # print("afterblock",x.shape)
        x = x.permute(0, 3, 1, 2)
        

        x = self.ins_norm(x)  # 应用 InstanceNorm2d
        # print("afterIns_norm_x",x.shape)
        x = self.act(x)       # 应用激活函数




        
        return x + skip * self.scale


class CMambaBlock1(nn.Module):
    def __init__(self, in_c, out_c,   
        
):
      super().__init__()
      self.in_c = in_c
      self.out_channels = out_c or in_c

      self.conv = nn.Conv2d(in_c, in_c, kernel_size=3, stride=1, padding='same', dilation=1, groups=in_c, bias=True, padding_mode='zeros')
      self.ins_norm = nn.InstanceNorm2d(in_c, affine=True)
      self.act = nn.LeakyReLU(negative_slope=0.01)
      self.block = VSSBlock(hidden_dim = in_c)
      # self.block = nn.Conv2d(in_c, in_c, k_size, stride=1, padding='same')
      self.scale = nn.Parameter(torch.ones(1))
      self.cnn_branch = nn.Sequential(
            nn.Conv2d(in_c, in_c, kernel_size=3, stride=1, padding='same', bias=True),
            nn.LeakyReLU(negative_slope=0.01),
            nn.Conv2d(in_c, in_c, kernel_size=6, stride=1, padding='same', bias=True),
            nn.LeakyReLU(negative_slope=0.01),
            nn.Conv2d(in_c, in_c, kernel_size=3, stride=1, padding='same', bias=True),
            nn.LeakyReLU(negative_slope=0.01)
        )
    def forward(self, x):

        skip = x

        x1 = self.conv(x)
        x1 = x1.permute(0, 2, 3, 1)
        print("x1",x1.shape)
        x1 = self.block(x1)
        x1 = x1.permute(0, 3, 1, 2)
        print("x1",x1.shape)
        x1 = self.act(self.ins_norm(x1))
     
        x2 = self.cnn_branch(x)
        print(x2.shape)
        x2=self.ins_norm(x2)
    
        return x1 + x2 + skip * self.scale

# test
if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    batch_size = 1
    channels = 1
    height =  256
    width=300
    x = torch.randn(batch_size, channels, height, width).to(device)
    model = CMambaBlock(in_c=channels,out_c=channels).to(device)
    output = model(x)
    print(output.shape)

# test_model()