import torch
from torch import Tensor, nn
# from typing import List
# import torchvision.transforms as transforms
# from PIL import Image
from torch import nn
from torch.nn import init
import math
# import numpy as np
# from models.FFST._shearletTransformSpect import shearletTransformSpect
# from models.FFST._inverseShearletTransformSpect import inverseShearletTransformSpect
import pywt
import torch.nn as nn
import torch
from pytorch_wavelets import DWTForward
import numpy as np
##小波变换
#非下采样小波变换
# 报错则安装：pip install pytorch_wavelets
"""    
    论文地址：https://arxiv.org/pdf/2401.15578
    论文题目：ASCNet: Asymmetric Sampling Correction Network for Infrared Image Destriping （TGRS 2025）
    中文题目：ASCNet：用于红外图像去条带的非对称采样校正网络 （TGRS 2025）
    讲解视频：https://www.bilibili.com/video/BV1bPJEzwE5J/
        残差Haar离散小波变换（Residual Haar Discrete Wavelet Transform，RHDWT）：
        实际意义：①离散小波变换的局限性：仅依赖空间采样和方向先验（如条带噪声的水平梯度特性），但缺乏跨通道的语义交互，导致特征仅包含空间信息，无法捕捉数据驱动的高层语义。
                ②步长卷积：虽能融合空间与全语义特征，但忽略噪声方向先验，导致特征中方向信息缺失。
        实现方式：双分支并行：①模型驱动分支：Haar小波分解，提取条带方向先验。
                           ②残差分支：卷积融合空间与跨通道语义。
        涨点以后如何写作？：【此部分 请务必看视频 视频更为详细】
"""

class SFBlock1(nn.Module):
    """残差小波变换 + 低/高频多频谱注意力"""
    def __init__(self, in_channels=32, n=1,
                 # 新增 attention 用到的参数
                 dct_h=224, dct_w=224,
                 reduction=16, freq_sel_method='top16'):
        super().__init__()
        # 残差路径
        self.identety = nn.Conv2d(in_channels, in_channels*n, 3, stride=1, padding=1)

        # DWT 分解（此处 wave='sym4'）
        self.DWT = DWTForward(J=1, wave='sym4')

        # —— 新增：低频/高频多频谱注意力 —— 
        self.att_low  = MultiSpectralAttentionLayer(
            channel=in_channels,
            dct_h=dct_h, dct_w=dct_w,
            reduction=reduction,
            freq_sel_method=freq_sel_method
        )
        self.att_high = MultiSpectralAttentionLayer(
            channel=in_channels*3,
            dct_h=dct_h, dct_w=dct_w,
            reduction=reduction,
            freq_sel_method=freq_sel_method
        )

        # 原来的编码
        self.dconv_encode = nn.Sequential(
            nn.Conv2d(in_channels*4, in_channels*n, 3, padding=1),
            nn.LeakyReLU(inplace=True),
        )

    def _transformer(self, low, high):
        # low: 低频特征 [N, C, H, W]
        # high: 高频特征 [N, 3C, H, W] 或 [N, C*3, H, W]
        return torch.cat([low, high], dim=1)  # 输出 [N, 4C, H, W]


    def forward(self, x):
        # x: [N, C, H, W]
        res = self.identety(x)

        # 转 numpy 做 SWT
        batch, C, H, W = x.shape
        arr = x[0].detach().cpu().numpy() # assume batch=1
        all_cA, all_high = [], []
        wavelet, level = 'db4', 3

        for ch in range(C):
            cA, (cH, cV, cD) = pywt.swt2(arr[ch], wavelet, level)[0]
            all_cA.append(cA)
            # 把 cH/cV/cD 再合成一个三维数组
            all_high.append(np.stack([cH, cV, cD], axis=0))

        cA_t = torch.from_numpy(np.stack(all_cA, axis=0))\
                    .unsqueeze(0).to(x.device).float()       # [1, C, H, W]
        high_t = torch.from_numpy(np.stack(all_high, axis=0))\
                       .unsqueeze(0).to(x.device).float()   # [1, C, 3, H, W]

        # flatten 高频的第三维 into channel
        n, C0, K, H0, W0 = high_t.shape
        high_freq = high_t.view(n, C0 * K, H0, W0)    # [1, 3C, H, W]

        # attention
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
     
        cA_t = cA_t.to(device)
        self.att_low=self.att_low.to(device)
        low_att  = self.att_low(cA_t)  
        self.att_high=self.att_high.to(device)  
        high_freq=high_freq.to(device)  # [1, C, H, W]
        high_att = self.att_high(high_freq)  # [1, 3C, H, W]
        # print("hello")
        # 拼接 + 编码
        DMT = self._transformer(low_att, high_att)  # [1, 4C, H, W]
        self.dconv_encode=self.dconv_encode.to(device)
        out = self.dconv_encode(DMT)                # [1, C, H, W]
        res = res.to(device)
        out=out + res
        return out

# 获取频率选择的索引
def get_freq_indices(method):# 确保方法在预定义的选择里
    assert method in ['top1', 'top2', 'top4', 'top8', 'top16', 'top32',
                      'bot1', 'bot2', 'bot4', 'bot8', 'bot16', 'bot32',
                      'low1', 'low2', 'low4', 'low8', 'low16', 'low32']
    num_freq = int(method[3:]) # 从方法名获取频率数量
    # 根据不同的选择方法获取频率的x和y索引
    if 'top' in method:  # 高频索引
        all_top_indices_x = [0, 0, 6, 0, 0, 1, 1, 4, 5, 1, 3, 0, 0,
                             0, 3, 2, 4, 6, 3, 5, 5, 2, 6, 5, 5, 3, 3, 4, 2, 2, 6, 1]
        all_top_indices_y = [0, 1, 0, 5, 2, 0, 2, 0, 0, 6, 0, 4, 6,
                             3, 5, 2, 6, 3, 3, 3, 5, 1, 1, 2, 4, 2, 1, 1, 3, 0, 5, 3]
        mapper_x = all_top_indices_x[:num_freq]
        mapper_y = all_top_indices_y[:num_freq]
    elif 'low' in method:# 低频索引
        all_low_indices_x = [0, 0, 1, 1, 0, 2, 2, 1, 2, 0, 3, 4, 0,
                             1, 3, 0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4]
        all_low_indices_y = [0, 1, 0, 1, 2, 0, 1, 2, 2, 3, 0, 0, 4,
                             3, 1, 5, 4, 3, 2, 1, 0, 6, 5, 4, 3, 2, 1, 0, 6, 5, 4, 3]
        mapper_x = all_low_indices_x[:num_freq]
        mapper_y = all_low_indices_y[:num_freq]
    elif 'bot' in method:# 底部频率索引
        all_bot_indices_x = [6, 1, 3, 3, 2, 4, 1, 2, 4, 4, 5, 1, 4,
                             6, 2, 5, 6, 1, 6, 2, 2, 4, 3, 3, 5, 5, 6, 2, 5, 5, 3, 6]
        all_bot_indices_y = [6, 4, 4, 6, 6, 3, 1, 4, 4, 5, 6, 5, 2,
                             2, 5, 1, 4, 3, 5, 0, 3, 1, 1, 2, 4, 2, 1, 1, 5, 3, 3, 3]
        mapper_x = all_bot_indices_x[:num_freq]
        mapper_y = all_bot_indices_y[:num_freq]
    else:
        raise NotImplementedError
    return mapper_x, mapper_y

# 多频谱注意力层
class MultiSpectralAttentionLayer(nn.Module):
    def __init__(self, channel, dct_h, dct_w, reduction=16, freq_sel_method='top16'):
        super(MultiSpectralAttentionLayer, self).__init__()
        self.reduction = reduction# 降维比例
        self.dct_h = dct_h# DCT变换的高度
        self.dct_w = dct_w# DCT变换的宽度

        mapper_x, mapper_y = get_freq_indices(freq_sel_method)# 获取频率选择的索引
        self.num_split = len(mapper_x)# 分割的数量
        # print("dct_h",dct_h)
        mapper_x = [temp_x * (dct_h // 7) for temp_x in mapper_x]# 调整索引以适应DCT高度
        mapper_y = [temp_y * (dct_w // 7) for temp_y in mapper_y]# 调整索引以适应DCT宽度
      

        self.dct_layer = MultiSpectralDCTLayer(
            dct_h, dct_w, mapper_x, mapper_y, channel)
        # print("channel",channel,reduction)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )
        # print("宽度和高度",self.dct_w,self.dct_h)
        self.avgpool = nn.AdaptiveAvgPool2d((self.dct_h, self.dct_w))

    def forward(self, x):
        # print(x.shape)
        n, c, h, w = x.shape # 获取输入形状
        x_pooled = x
        if h != self.dct_h or w != self.dct_w: 
            x_pooled = self.avgpool(x)# 如果输入尺寸不匹配，进行池化
        # print("x在批破哦",x_pooled.shape)
        y = self.dct_layer(x_pooled)
        # print("y在pool",y.shape)
        y = y.float()
        # print("y.float",y.shape)
        y_c = y.shape[1]
        # print("我要找yc",y_c)
        # print(x.shape)
        x_in_channels = x.shape[1]
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        conv = nn.Conv2d(in_channels=x_in_channels, out_channels=y_c, kernel_size=1).to(device)
        # print("inchannels",x_in_channels,y_c)
        x=x.to(device)
        x = conv(x)
        # print("y的形状")
        # print(y.shape)
        # print(x.shape)
        # print(y.device)
        # print("x.device",x.device)
        y = self.fc(y).view(n, y_c, 1, 1)
        return x * y.expand_as(x)

 # 实现多频谱DCT层
class MultiSpectralDCTLayer(nn.Module):
   

    def __init__(self, height, width, mapper_x, mapper_y, channel):
        super(MultiSpectralDCTLayer, self).__init__()
        # print("channel",channel)
        assert len(mapper_x) == len(mapper_y)  # 确保x和y索引的长度相同
        assert channel % len(mapper_x) == 0 # 确保通道数可以被频率数量整除

        self.num_freq = len(mapper_x) # 频率数量

    # 获取DCT滤波器
        self.weight = self.get_dct_filter(
            height, width, mapper_x, mapper_y, channel)

    def forward(self, x):
        assert len(x.shape) == 4, 'x must been 4 dimensions, but got ' + \
                                  str(len(x.shape))
        # n, c, h, w = x.shape

        weight = self.weight.unsqueeze(0)
        #调整x的形状
        in_channels = x.shape[1] 
        out_channels = weight.shape[1]
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1).to(device)
        x=x.to(device)
        x = conv(x)
        
        weight=weight.to(device)
        x = x * weight # 将DCT滤波器应用于输入
        result = torch.sum(torch.sum(x, dim=2), dim=2) # 求和以获取最终结果
        return result

    def build_filter(self, pos, freq, POS):# 构建DCT滤波器的辅助函数，计算DCT基函数值
        result = math.cos(math.pi * freq * (pos + 0.5) / POS) / math.sqrt(POS)
        if freq == 0:
            return result
        else:
            return result * math.sqrt(2)
# 生成DCT滤波器，mapper_x和mapper_y定义了选中的DCT频率
    def get_dct_filter(self, tile_size_x, tile_size_y, mapper_x, mapper_y, channel):
        dct_filter = torch.zeros((channel, tile_size_x, tile_size_y))# 计算每个频率对应的通道数

        c_part = channel // len(mapper_x)

        for i, (u_x, v_y) in enumerate(zip(mapper_x, mapper_y)):
            for t_x in range(tile_size_x):
                for t_y in range(tile_size_y):
                    # 对每个位置应用build_filter函数，构建DCT滤波器
                    dct_filter[i * c_part: (i + 1) * c_part, t_x, t_y] = self.build_filter(
                        t_x, u_x, tile_size_x) * self.build_filter(t_y, v_y, tile_size_y)

        return dct_filter


# —— 测试 ——  
if __name__ == "__main__":
    # 测试 SFBlock
    # 假设输入通道为 32，输出也不扩展（n=1），
    # 并且你希望注意力模块里 DCT 操作在 64×64 的特征图上进行：
    in_ch   = 32
    dct_h   = 224
    dct_w   = 224
    block   = SFBlock1(
        in_channels    = in_ch,
        n              = 1,
        dct_h          = dct_h,
        dct_w          = dct_w,
        reduction      = 16,
        freq_sel_method= 'top16'
    )
    block.eval()

    # 随机生成一个批量为 2，大小为 128×128 的特征图
    x = torch.randn(1, in_ch, dct_h, dct_w)

    with torch.no_grad():
        out = block(x)

    print(f"Input shape : {x.shape}")
    print(f"Output shape: {out.shape}")
    # 期望输出为 [2, in_ch, dct_h, dct_w]，也就是 [2,32,64,64]