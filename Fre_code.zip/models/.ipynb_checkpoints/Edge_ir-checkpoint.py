import torch
from torch import Tensor, nn
from models.base import DWConv2d
from typing import List
import torchvision.transforms as transforms
from PIL import Image
from torch import nn
import numpy as np
class InvertedResidualBlock(nn.Module):
    def __init__(self, inp, oup, expand_ratio):
        super(InvertedResidualBlock, self).__init__()
        hidden_dim = int(inp * expand_ratio)
        # print("inp",inp)
        self.bottleneckBlock = nn.Sequential(
            # pw
            nn.Conv2d(inp, hidden_dim, 1, bias=False),
            # nn.BatchNorm2d(hidden_dim),
            nn.ReLU6(inplace=True),
            # dw
            nn.ReflectionPad2d(1),
            nn.Conv2d(hidden_dim, hidden_dim, 3, groups=hidden_dim, bias=False),
            # nn.BatchNorm2d(hidden_dim),
            nn.ReLU6(inplace=True),
            # pw-linear
            nn.Conv2d(hidden_dim, oup, 1, bias=False),
            # nn.BatchNorm2d(oup),
        )

    def forward(self, x):
        # print("xInv",x.shape)
        return self.bottleneckBlock(x)


class DetailNode(nn.Module):
    def __init__(self):
        super(DetailNode, self).__init__()
        
        self.theta_phi = InvertedResidualBlock(inp=8, oup=8, expand_ratio=2)
        self.theta_rho = InvertedResidualBlock(inp=8, oup=8, expand_ratio=2)
        self.theta_eta = InvertedResidualBlock(inp=8, oup=8, expand_ratio=2)
        self.shffleconv = nn.Conv2d(16, 16, kernel_size=1,
                                    stride=1, padding=0, bias=True)

    def separateFeature(self, x):
        # print("xde1")
        # print(x.shape)
        z1, z2 = x[:, :x.shape[1] // 2], x[:, x.shape[1] // 2:x.shape[1]]
        return z1, z2

    def forward(self, z1, z2):
        # print("Before shuffleconv:", z1.shape, z2.shape)
        z1, z2 = self.separateFeature(
            self.shffleconv(torch.cat((z1, z2), dim=1)))
        # print("After shuffleconv:", z1.shape, z2.shape)
        z2 = z2 + self.theta_phi(z1)
        # print("z21",z2.shape,z1.shape)
        z1 = z1 * torch.exp(self.theta_rho(z2)) + self.theta_eta(z2)
        return z1, z2


class DetailFeatureExtraction(nn.Module):
    def __init__(self, num_layers=3,in_channels=32):
        super(DetailFeatureExtraction, self).__init__()
        INNmodules = [DetailNode() for _ in range(num_layers)]
        self.net = nn.Sequential(*INNmodules)

    def forward(self, x):
        z1, z2 = x[:, :x.shape[1] // 2], x[:, x.shape[1] // 2:x.shape[1]]
        # print(z1.shape,z2.shape)
        for layer in self.net:
            z1, z2 = layer(z1, z2)
        
    
        return torch.cat((z1, z2), dim=1)

# class InvertedResidualBlock(nn.Module):
#     def __init__(self, inp, oup, expand_ratio):
#         super(InvertedResidualBlock, self).__init__()
#         # print("inp",inp)
#         # print("expand",expand_ratio)
#         hidden_dim = int(inp * expand_ratio)
#         self.bottleneckBlock = nn.Sequential(
#             nn.Conv2d(inp, hidden_dim, 1, bias=False),
#             nn.ReLU6(inplace=True),
#             nn.ReflectionPad2d(1),
#             nn.Conv2d(hidden_dim, hidden_dim, 3, groups=hidden_dim, bias=False),
#             nn.ReLU6(inplace=True),
#             nn.Conv2d(hidden_dim, oup, 1, bias=False),
#         )

#     def forward(self, x):
#         return self.bottleneckBlock(x)

# class DetailNode(nn.Module):
#     def __init__(self, channels):
#         super(DetailNode, self).__init__()
#         # print("channels",channels)
#         self.shffleconv = nn.Conv2d(
#             channels, channels, kernel_size=1, stride=1, padding=0, bias=True
#         )
#         self.theta_phi = InvertedResidualBlock(inp=channels, oup=channels, expand_ratio=2)
#         self.theta_rho = InvertedResidualBlock(inp=channels, oup=channels, expand_ratio=2)
#         self.theta_eta = InvertedResidualBlock(inp=channels, oup=channels, expand_ratio=2)
#     def forward(self, z):

        
#         x = self.shffleconv(z)
#         z = x
#         z = z + self.theta_phi(z)  # 应用 theta_phi
#         z = z * torch.exp(self.theta_rho(z)) + self.theta_eta(z)  # 继续执行INN逻辑
#         if z.shape[1] != x.shape[1]:
#             z = self.adjust_channels(z)
#         return z


# class DetailFeatureExtraction1(nn.Module):
#     def __init__(self, num_layers=3, in_channels=1):
#         super(DetailFeatureExtraction1, self).__init__()
#         INNmodules = [DetailNode(channels=in_channels) for _ in range(num_layers)]

#         self.net = nn.Sequential(*INNmodules)

#     def forward(self, x):
#         for layer in self.net:
#             x = layer(x)  
#         return x  
class Sobel(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        sobel_x = torch.tensor([
            [1, 0, -1],
            [2, 0, -2],
            [1, 0, -1],
        ])
        self.sobel_x = DWConv2d(channels, sobel_x, padding=1, padding_mode='replicate')
        self.sobel_y = DWConv2d(channels, sobel_x.T, padding=1, padding_mode='replicate')

    def forward(self, x: Tensor) -> Tensor:
        return self.sobel_x(x) + self.sobel_y(x)

class Laplacian(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        laplacian = torch.tensor([
            [0,  1, 0],
            [1, -4, 1],
            [0,  1, 0]
        ])
        self.dw = DWConv2d(channels, laplacian, padding=1)

    def forward(self, x: Tensor) -> Tensor:
        return self.dw(x)

class ChannelAttentionLayer(nn.Module):
    def __init__(self, channels: int, ratio: float = 0.25) -> None:
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        # print("channel",channels,ratio)
        hidden_dim = max(1,int(channels * ratio))
        self.fc = nn.Sequential(
            nn.Conv2d(channels, hidden_dim, 1, bias=False),
            nn.LeakyReLU(),
            nn.Conv2d(hidden_dim, channels, 1, bias=False)
        )
        self.sigmod = nn.Sigmoid()

    def forward(self, x: Tensor) -> Tensor:
        x_avg = self.fc(self.avg_pool(x))
        x_max = self.fc(self.max_pool(x))
        x_CA = self.sigmod(x_avg + x_max) * x
        return  x_CA

class SpatialAttentionLayer(nn.Module):
    def __init__(self, kernel_size: int = 7):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False, padding_mode='replicate')
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: Tensor) -> Tensor:
        x_avg = torch.mean(x, dim=1, keepdim=True)
        x_max = torch.max(x, dim=1, keepdim=True).values
        weights = torch.cat([x_avg, x_max], dim=1)
        x_SA = self.sigmoid(self.conv(weights)) * x
        return x_SA

class CBAM(nn.Module):
    def __init__(self, channels: int, ratio: float = 0.25) -> None:
        super().__init__()
        self.channel_attn = ChannelAttentionLayer(channels, ratio)
        self.spatial_attn = SpatialAttentionLayer()
    
    def forward(self, x: Tensor) -> Tensor:

        x = self.channel_attn(x)
        return self.spatial_attn(x)

class Edge_irConvBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int
    ) -> None:
        super().__init__()
        self.use_residual = in_channels == out_channels
        self.attn = CBAM(out_channels if in_channels != out_channels else in_channels)
        self.adjust_channels = nn.Conv2d(
            in_channels, out_channels, kernel_size=1, stride=1, bias=False
        ) if in_channels != out_channels else None      
        
        # Use adjusted channels if in_channels != out_channels
        feature_channels = out_channels if self.adjust_channels else in_channels      
        self.inn = DetailFeatureExtraction(num_layers=3, in_channels=feature_channels)
        self.sobel = nn.Sequential(
            DetailFeatureExtraction(num_layers=3, in_channels=feature_channels),
            Sobel(feature_channels)
        )
        self.lap = nn.Sequential(
            DetailFeatureExtraction(num_layers=3, in_channels=feature_channels),
            Laplacian(feature_channels)
        )
        
        self.act = nn.LeakyReLU()
        self.norm = nn.InstanceNorm2d(feature_channels)
    
    def forward(self, x: Tensor) -> Tensor:
        # print("x  shape",x.shape)
        # z1, z2 = x[:, :x.shape[1] // 2], x[:, x.shape[1] // 2:]
        # print("z1de",z1.shape)
        # print("z2de",z2.shape)
        # x_combined = torch.cat((z1, z2), dim=1)
        # print("xcombine",x_combined.shape)
        if self.adjust_channels:
            x = self.adjust_channels(x)
        out_inn = self.inn(x)
        # print("out_inn shape:", out_inn.shape)

        out_sobel = self.sobel(x)
        # print("sobel shape:", out_sobel.shape)

        out_lap = self.lap(x)
        # print("lap shape:", out_lap.shape)

        out = out_lap + out_sobel+out_inn
        # out = self.attn(out) 
        out = self.act(self.norm(out))
        if self.use_residual:
            out = out + x
        return out

# test
if __name__ == '__main__':


    input_tensor = torch.rand(1, 32, 128, 120)  
    model = Edge_irConvBlock(in_channels=1, out_channels=1)
    model.eval()
    with torch.no_grad():
        output = model(input_tensor)
    print("Output shape:", output.shape)