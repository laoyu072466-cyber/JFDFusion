from dataclasses import dataclass
from itertools import pairwise
from torch.nn import LayerNorm
import torch
from torch import nn, Tensor
# from decoder import VMamba
# from FusionLayers import dense_resnet34
from models.attention import SpatialAttentionLayer
from models.attention import ChannelAttentionLayer
# from attention import CBAM
# from edge import EdgeConvBlock
# from transformer import Transformer
from models.fusionlayer import ModularNetwork
from models.Edge_ir import Edge_irConvBlock # type: ignore
from models.decoder import CSBlock
from models.CMblock import CMambaBlock,CMambaBlock1

@dataclass
class FuseInput:
    vi: Tensor
    ir: Tensor

@dataclass
class FuseOutput:
    fusion: Tensor
    vi_reconstruction: Tensor
    ir_reconstruction: Tensor
    vi_feature_commom: Tensor
    ir_feature_common: Tensor
    vi_feature_private: Tensor
    ir_feature_private: Tensor


class ECB(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, channels_list: list[int]) -> None:
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.proj_in = nn.Conv2d(in_channels, channels_list[0], 1) # 利用一个 1x1 的卷积层，用于将输入的通道数从 in_channels 转换为 channels_list[0]
        self.conv_blocks = nn.Sequential(
            *[nn.Conv2d(cur, nxt, kernel_size=3, padding=1) for cur, nxt in pairwise(channels_list)] # 利用普通卷积层进行通道数变换
        )
        self.edge_ir_block = Edge_irConvBlock(channels_list[-1], channels_list[-1]) # 在通道变换完成后使用 Edge_irConvBlock
        self.proj_out = nn.Conv2d(channels_list[-1], out_channels, 1) # 通道调整，将输出通道从高纬度调整为低维通道
    
    def forward(self, x: Tensor) -> Tensor:
        # print("x",x.shape)
        x = self.proj_in(x)
        # print("after proj_out",x.shape)
        x = self.conv_blocks(x)
        # print("after_convblocks",x.shape)
        x = self.edge_ir_block(x)
        # print("afteredge_ir",x.shape)
       
        return self.proj_out(x)

class SimpleDecoder(nn.Module):
    def __init__(self, in_channels: int, mid_channels: list[int]):
        super().__init__()
        # 确保中间通道列表包含两个元素，因为我们需要三个卷积层
        assert len(mid_channels) == 2, "mid_channels list must contain exactly two elements for the two intermediate convolution layers."

        # 第一个卷积层
        self.conv1 = nn.Conv2d(in_channels, mid_channels[0], kernel_size=3, padding=1)
        self.relu1 = nn.ReLU(inplace=True)

        # 第二个卷积层
        self.conv2 = nn.Conv2d(mid_channels[0], mid_channels[1], kernel_size=3, padding=1)
        self.relu2 = nn.ReLU(inplace=True)

        # 第三个卷积层，输出通道为1
        self.conv3 = nn.Conv2d(mid_channels[1], 1, kernel_size=3, padding=1)
        self.tanh = nn.Tanh()

    def forward(self, x):
        # print("beforeDecoder",x.shape)
        x = self.conv1(x)
        # print("decoder1",x.shape)
        x = self.relu1(x)
        x = self.conv2(x)
        # print("decoder2",x.shape)
        x = self.relu2(x)
        x = self.conv3(x)
        # print("decoder3",x.shape)
        x = self.tanh(x)
        return x
    
class DBTFuse(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        num_features: int,
        channels_list: list[int],
        patch_size: int,
        dropout = 0.0,
        bias = False,
        
    ):
        super().__init__()
        self.channels_list = channels_list
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.encode_vi = ECB(in_channels, num_features, channels_list) #encoder for VIS
        self.encode_ir = ECB(in_channels, num_features, channels_list) #encoder for IR
        self.encode_comm = CMambaBlock(in_channels,out_channels)
        # print(f"self.encode_comm.out_channels: {self.encode_comm.out_channels}")
        self.conv = nn.Conv2d(2, 4, kernel_size=3, stride=1, padding='same', dilation=1, groups=in_channels, bias=True, padding_mode='zeros')
        self.act = nn.LeakyReLU(negative_slope=0.01)
        self.ln_vi = nn.BatchNorm2d(4)
        self.ln_ir = nn.BatchNorm2d(4)
        self.patch_size = 16
        # self.decoder = CSBlock(
        #     d_model=32,
        #     d_state=16,
        #     expand=2,
        #     dt_rank=8,
        #     dropout=dropout
        # )
        # print("num_features",num_features)
        decoder_channels = [num_features + num_features, 32, 16] # 解码器层的通道数
        self.decoder_vi = SimpleDecoder(num_features+2, decoder_channels[1:])
        self.decoder_ir = SimpleDecoder(num_features+2, decoder_channels[1:])
        self.decoder_fuse = SimpleDecoder(130, decoder_channels[1:])
        self.fusion_strategy = ModularNetwork(num_features+2, num_blocks=3, kernel_size=3, stride=1)
        # print("卷积核",(self.encode_ir.out_channels))
        self.attn_vi = SpatialAttentionLayer(self.encode_ir.out_channels)
        self.attn_ir = ChannelAttentionLayer(self.encode_ir.out_channels)
        self.proj_out = nn.Tanh()


    def forward(self, inputs: FuseInput):
        # print("输入")
        # print((inputs.vi).shape)
        # print((inputs.ir).shape)
        p_vi = self.encode_vi(inputs.vi)
        p_ir = self.encode_ir(inputs.ir)
        f_vi = self.encode_comm(inputs.vi)
        f_ir = self.encode_comm(inputs.ir)
        # print("p_vi",p_vi.shape)
        # print("p_ir",p_vi.shape)
        # print("f_vi",f_ir.shape)
        # print("f_ir",f_ir.shape)
        a=self.attn_vi(p_vi)
        b=self.attn_ir(p_ir)
        # print("a",a.shape)
        # print("b",b.shape)
        priv = self.attn_vi(p_vi) + self.attn_ir(p_ir)
        comm = torch.max(f_vi, f_ir)
        # print("comm",comm.shape)
        merged = torch.cat([priv, comm], dim=1)
        # print("merged",merged.shape)
        merged = self.fusion_strategy(merged)
        # print("merged",merged.shape)
        r_vi = torch.cat([p_vi, comm], dim=1)
        r_ir = torch.cat([p_ir, comm], dim=1)
        r_ir = self.proj_out(self.decoder_ir(r_ir))
        r_vi = self.proj_out(self.decoder_vi(r_vi))
        fuse = self.proj_out(self.decoder_fuse(merged))
        # print("fuse",fuse.shape)
      
        return FuseOutput(
            fusion=fuse.clamp(-1.0, 1.0),
            vi_reconstruction=r_vi.clamp(-1.0, 1.0),
            ir_reconstruction=r_ir.clamp(-1.0, 1.0),
            vi_feature_commom=f_vi,
            ir_feature_common=f_ir,
            vi_feature_private=p_vi,
            ir_feature_private=p_ir,
        )

    def frozen(self, *__names: str):
        for name, param in self.named_parameters():
            for _name in __names:
                if _name in name:
                    param.requires_grad = False
                    print('frozen layer:', name)

# if __name__ == '__main__':
#     model = DBTFuse(
#         in_channels=1,
#         out_channels=1,
#         num_features=64,
#         channels_list=[4, 8, 16, 16],
#         patch_size=16,
#         num_heads=32,
#         num_layers=4,
#         embed_dim=1024,
#         dropout=0.1,
#         bias=False
#     )

#     vi=torch.randn(1, 1, 256, 256)
#     ir=torch.randn(1, 1, 256, 256)
if __name__ == '__main__':
    model = DBTFuse(
        in_channels=1,
        out_channels=1,
        num_features=32,
        channels_list=[4, 8, 16],
        patch_size=16,
        dropout=0.1,
        bias=False
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    vi = torch.randn(4, 1, 224, 224).to(device)  # input VIS,batchsize=3,channel=3
    ir = torch.randn(4, 1,224, 224).to(device)  # input IR

    fuse_input = FuseInput(vi=vi, ir=ir)

    with torch.no_grad():  
        fuse_output = model(fuse_input)


    print(f"Fusion output shape: {fuse_output.fusion.shape}")
    print(f"VI reconstruction output shape: {fuse_output.vi_reconstruction.shape}")
    print(f"IR reconstruction output shape: {fuse_output.ir_reconstruction.shape}")
    print(f"VI common features shape: {fuse_output.vi_feature_commom.shape}")
    print(f"IR common features shape: {fuse_output.ir_feature_common.shape}")
    print(f"VI private features shape: {fuse_output.vi_feature_private.shape}")
    print(f"IR private features shape: {fuse_output.ir_feature_private.shape}")
    # from thop import profile, clever_format
    # FLOPs, Params = profile(model, inputs=FuseInput(vi, ir))
    # print(FLOPs, Params)
    # FLOPs, Params = clever_format([FLOPs * 2, Params], '%.4f')
    # print(FLOPs, Params)
