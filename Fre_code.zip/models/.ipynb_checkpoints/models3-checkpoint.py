from dataclasses import dataclass
# from itertools import pairwise
# from torch.nn import LayerNorm
import torch
import torch.nn.functional as F
from torch import nn, Tensor

from models.fusionlayer import ModularNetwork
from models.Edge1 import SFBlock1
from models.CMblock import SS2D1

@dataclass
class FuseInput:
    vi: Tensor
    ir: Tensor

@dataclass
class FuseOutput:
    fusion: Tensor
    ir_out: Tensor
    vi_out: Tensor


#解码器
class SimpleDecoder(nn.Module):
    def __init__(self, in_channels: int, mid_channels: list[int]):
        super().__init__()
        # 确保中间通道列表包含两个元素，因为我们需要三个卷积层
        assert len(mid_channels) == 2, "mid_channels list must contain exactly two elements for the two intermediate convolution layers."

        # 第一个卷积层
        self.conv1 = nn.Conv2d(in_channels, mid_channels[0], kernel_size=3, padding=1)
        self.relu1 = nn.ReLU(inplace=True)

        # 第二个卷积层
        self.conv2 = nn.Conv2d(mid_channels[0], mid_channels[1], kernel_size=3, padding=1)
        self.relu2 = nn.ReLU(inplace=True)

        # 第三个卷积层，输出通道为1
        self.conv3 = nn.Conv2d(mid_channels[1], 1, kernel_size=3, padding=1)
        self.tanh = nn.Tanh()

    def forward(self, x):
        # print("beforeDecoder",x.shape)
        x = self.conv1(x)
        # print("decoder1",x.shape)
        x = self.relu1(x)
        x = self.conv2(x)
        # print("decoder2",x.shape)
        x = self.relu2(x)
        x = self.conv3(x)
        # print("decoder3",x.shape)
        x = self.tanh(x)
        return x

#权重选择
class CAM(nn.Module):
    def __init__(self):
        super().__init__()
        # 定义一个可学习的参数gamma，初始值为0
        self.gamma = nn.Parameter(torch.zeros(1))
        # 定义一个Softmax层，用于在最后一个维度上进行softmax操作
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, img_feat, text_feat):
        # 获取图像特征张量的形状，B为批次大小，C为通道数，H为高度，W为宽度
        B, C, H, W = img_feat.shape

        # 将图像特征张量进行变形，将后两个维度展平，方便后续矩阵乘法操作
        q = img_feat.view(B, C, -1)
        # 将文本特征张量进行变形，展平后交换最后两个维度，以便后续与q进行矩阵乘法
        k = text_feat.view(B, C, -1).permute(0, 2, 1)
        # 计算图像特征和文本特征的注意力映射，通过矩阵乘法得到
        attention_map = torch.bmm(q, k)
        # 对注意力映射进行softmax操作，使其值在0到1之间且总和为1
        attention_map = self.softmax(attention_map)

        # 将文本特征张量进行变形，展平以便后续与注意力映射进行矩阵乘法
        v = text_feat.view(B, C, -1)
        # 通过注意力映射对文本特征进行加权，得到注意力信息
        attention_info = torch.bmm(attention_map, v)
        # 将注意力信息的形状恢复为与输入图像特征相同的形状
        attention_info = attention_info.view(B, C, H, W)
        # 将注意力信息与图像特征进行加权融合，得到最终输出
        output = self.gamma * attention_info + img_feat
        return output

#增强
class LayerNormFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, bias, eps):
        # 保存epsilon值用于反向传播
        ctx.eps = eps
        # 获取输入张量的维度：[批量大小, 通道数, 高度, 宽度]
        N, C, H, W = x.size()
        # 计算每个样本在通道维度上的均值
        mu = x.mean(1, keepdim=True)
        # 计算每个样本在通道维度上的方差
        var = (x - mu).pow(2).mean(1, keepdim=True)
        # 对输入进行归一化处理
        y = (x - mu) / (var + eps).sqrt()
        # 保存中间变量用于反向传播
        ctx.save_for_backward(y, var, weight)
        # 应用可学习的缩放和偏移参数
        y = weight.view(1, C, 1, 1) * y + bias.view(1, C, 1, 1)
        return y

    @staticmethod
    def backward(ctx, grad_output):
        # 获取保存的epsilon值
        eps = ctx.eps
        # 获取梯度张量的维度
        N, C, H, W = grad_output.size()
        # 获取前向传播中保存的中间变量
        y, var, weight = ctx.saved_variables
        # 计算权重缩放后的梯度
        g = grad_output * weight.view(1, C, 1, 1)
        # 计算梯度在通道维度上的均值
        mean_g = g.mean(dim=1, keepdim=True)
        # 计算梯度与归一化输入乘积的均值
        mean_gy = (g * y).mean(dim=1, keepdim=True)
        # 计算输入的梯度
        gx = 1. / torch.sqrt(var + eps) * (g - y * mean_gy - mean_g)
        # 返回各个输入的梯度：输入x、权重weight、偏置bias和eps(None表示不需要梯度)
        return gx, (grad_output * y).sum(dim=3).sum(dim=2).sum(dim=0), grad_output.sum(dim=3).sum(dim=2).sum(dim=0), None

class LayerNorm2d(nn.Module):
    def __init__(self, channels, eps=1e-6):
        super(LayerNorm2d, self).__init__()
        # 注册可学习的缩放参数，初始化为1
        self.register_parameter('weight', nn.Parameter(torch.ones(channels)))
        # 注册可学习的偏移参数，初始化为0
        self.register_parameter('bias', nn.Parameter(torch.zeros(channels)))
        # 设置归一化时的小常数，防止除零
        self.eps = eps

    def forward(self, x):
        # 调用自定义的LayerNorm函数进行前向传播
        return LayerNormFunction.apply(x, self.weight, self.bias, self.eps)

class FreMLP(nn.Module):
    def __init__(self, nc, expand=2):
        super(FreMLP, self).__init__()
        # 定义频域处理模块：1x1卷积扩展通道 -> LeakyReLU激活 -> 1x1卷积恢复通道
        self.process1 = nn.Sequential(
            nn.Conv2d(nc, expand * nc, 1, 1, 0),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(expand * nc, nc, 1, 1, 0))

    def forward(self, x):
        # 获取输入张量的维度
        _, _, H, W = x.shape
        # 对输入进行二维实值快速傅里叶变换，转换到频域
        x_freq = torch.fft.rfft2(x, norm='backward')
        # 计算频域表示的幅度
        mag = torch.abs(x_freq)
        # 计算频域表示的相位
        pha = torch.angle(x_freq)
        # 对幅度谱进行卷积处理
        mag = self.process1(mag)
        # 从处理后的幅度和原始相位重建频域复数表示
        real = mag * torch.cos(pha)
        imag = mag * torch.sin(pha)
        x_out = torch.complex(real, imag)
        # 对重建的频域表示进行逆傅里叶变换，转回空间域
        x_out = torch.fft.irfft2(x_out, s=(H, W), norm='backward')
        return x_out

class Frequency_Domain(nn.Module):
    def __init__(self, channels=32):
        super().__init__()
        # 实例化LayerNorm2d对输入进行归一化，注意这里c未定义，应为channels
        # print(f"Input shape: {inp.shape}")
        # print(f"Weight shape: {self.weight.shape}")
        # print(f"Bias shape: {self.bias.shape}")
        # print("Freql的channels",channels)
        self.norm = LayerNorm2d(channels)
        # 实例化频域处理模块
        self.freq = FreMLP(nc=channels, expand=2)
        # 可学习的缩放参数，初始化为0
        self.gamma = nn.Parameter(torch.zeros((1, channels, 1, 1)), requires_grad=True)
        # 可学习的偏移参数，初始化为0
        self.beta = nn.Parameter(torch.zeros((1, channels, 1, 1)), requires_grad=True)

    def forward(self, inp):
        # 保存输入作为残差连接
        A = inp
        # 对输入进行归一化
        # print("inp",inp.shape)
        x_step2 = self.norm(inp)  # 尺寸 [B, 2*C, H, W]
        # 在频域处理归一化后的特征
        x_freq = self.freq(x_step2)  # 尺寸 [B, C, H, W]
        # 将原始输入与频域处理结果相乘
        x = A * x_freq
        # 应用残差连接和可学习的缩放参数
        x = A + x * self.gamma
        return x
    
#整体模型
class DBTFuse3(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        num_features: int,

        patch_size: 16
    ):
        super().__init__()
    
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.edge=SFBlock1()

        self.freq_domain_vi = Frequency_Domain()
        self.Mam = SS2D1()
        # print(f"self.encode_comm.out_channels: {self.encode_comm.out_channels}")
        self.conv = nn.Conv2d(2, 4, kernel_size=3, stride=1, padding='same', dilation=1, groups=in_channels, bias=True, padding_mode='zeros')
        self.act = nn.LeakyReLU(negative_slope=0.01)
        self.ln_vi = nn.InstanceNorm2d(4)
        self.ln_ir = nn.InstanceNorm2d(4)
        self.cm= CAM()
        self.conv_ir = nn.Conv2d(in_channels, 32, kernel_size=3, stride=1, padding=1)
        decoder_channels = [num_features + num_features, 32, 16] # 解码器层的通道数
        self.decoder_vi = SimpleDecoder(num_features, decoder_channels[1:])
        self.decoder_ir = SimpleDecoder(num_features, decoder_channels[1:])
        self.decoder_fuse = SimpleDecoder(48, decoder_channels[out_channels:])
        self.fusion_strategy = ModularNetwork(num_features, num_blocks=1, kernel_size=3, stride=1)
        # print("卷积核",(self.encode_ir.out_channels))

        self.proj_out = nn.Tanh()


    def forward(self, inputs: FuseInput):
        # print("输入")
        # print((inputs.vi).shape)
        # print((inputs.ir).shape)
        # print("ir1M之前的输入",inputs.vi.shape)
        # print("ir1M之前的输入",inputs.ir.shape)
        ir_N = self.conv_ir(inputs.ir)  # 这里将 inputs.ir 的通道数卷积为32
        ir_N = self.edge(ir_N)
        
        vi_N = self.conv_ir(inputs.vi)  # 这里将 inputs.ir 的通道数卷积为32
        vi_N=self.edge(vi_N)
        # print("输入vi")
        # print(vi_N.shape)
        # print("输入IR",ir_N.shape)
        # vi_E = vi_E.permute(0, 3, 2, 1)
        ##经过EFE.py
        # ir_E = ir_E.permute(0, 3, 2, 1)
        # print("ir2M之前的输入",ir_N.shape)
        # print("ir2M之前的输入",vi_N.shape)
        ##经过CMBlock.py
        ir_S = self.freq_domain_vi(ir_N)
        vi_M = self.Mam(vi_N)
        ir_M = self.Mam(ir_S)

        # vi_M = vi_M.permute(0,3,1,2).contiguous()  # [B, H, W, C1]
        # ir_M = ir_M.permute(0,3,1,2).contiguous()  # [B, H, W, C2]
        # print("Vi_M",vi_M.shape)
        fused = self.cm(ir_M,vi_M)
                # print("w_vi",w_vi)
        # fusion = w_ir+w_vi
    
        # print("fusion",fusion.shape)
        # print("形状",fused.shape)
        merged = self.fusion_strategy(fused)
        # print("merged",merged.shape)
        r_ir = self.proj_out(self.decoder_ir(ir_M))
        r_vi = self.proj_out(self.decoder_vi(vi_M))
        fusion = self.proj_out(self.decoder_fuse(merged))
        # fusion = torch.nn.functional.interpolate(fusion, size=(224, 224), mode='bilinear', align_corners=False)
        # fuse = self.proj_out(self.decoder_fuse(comm))
        # print("fuse",fusion.shape)
        # print('r_vi',r_vi.shape)
        # print(f"Output min: {fusion.min().item()}, max: {fusion.max().item()}, mean: {fusion.mean().item()}")
        return FuseOutput(
            fusion=fusion.clamp(-1.0, 1.0),
            vi_out=r_vi.clamp(-1.0, 1.0),
            ir_out=r_ir.clamp(-1.0, 1.0)
        )

    def frozen(self, *__names: str):
        for name, param in self.named_parameters():
            for _name in __names:
                if _name in name:
                    param.requires_grad = False
                    print('frozen layer:', name)

if __name__ == '__main__':
    model = DBTFuse(
        in_channels=1,
        out_channels=1,
        num_features=48,
        patch_size= 16

    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    vi = torch.randn(1,1, 224, 224).to(device)  # input VIS,batchsize=3,channel=3
    ir = torch.randn(1, 1,224, 224).to(device)  # input IR

    fuse_input = FuseInput(vi=vi, ir=ir)

    with torch.no_grad():  
        fuse_output = model(fuse_input)


    print(f"Fusion output shape: {fuse_output.fusion.shape}")
