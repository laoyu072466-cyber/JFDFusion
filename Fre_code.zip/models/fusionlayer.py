import torch
import torch.nn as nn
import torch.nn.functional as F

class AttnFuseLitePlus(nn.Module):
    """
    轻量卷积注意力融合：
      w = sigmoid( PW1x1( DW3x3([X_ir, X_vi]) ) )
      F = w*X_ir + (1-w)*X_vi
      F = F + gamma * Conv3x3(F)   # 细化（可学习缩放）
    参数:
      C: 特征通道数
      per_channel: True -> 逐通道注意力；False -> 单通道空间注意力
      use_se: 是否在权重分支加入SE通道压缩（默认关，保轻量）
    """
    def __init__(self, C: int, per_channel: bool = True, use_se: bool = False):
        super().__init__()
        out_ch = C if per_channel else 1
        in_ch  = 2 * C

        # 1) 生成注意力 w 的轻量卷积分支：DW 3x3 -> BN -> SiLU -> PW 1x1
        self.dw = nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, groups=in_ch, bias=False)
        self.bn = nn.BatchNorm2d(in_ch)
        self.pw = nn.Conv2d(in_ch, out_ch, kernel_size=1, bias=True)

        self.use_se = use_se
        if use_se:
            r = max(1, C // 8)
            # 对2C做SE，再广播到 out_ch（保持轻量）
            self.se_gap   = nn.AdaptiveAvgPool2d(1)
            self.se_fc1   = nn.Conv2d(in_ch, r, 1)
            self.se_fc2   = nn.Conv2d(r, in_ch, 1)

        self.act = nn.SiLU()
        self.sig = nn.Sigmoid()

        # 2) 融合后细化：Conv 3x3 + 可学习缩放 gamma
        self.refine = nn.Conv2d(C, C, kernel_size=3, padding=1, bias=True)
        self.gamma  = nn.Parameter(torch.tensor(1e-3))  # 小初值，稳

    def _attn_weight(self, x_ir, x_vi):
        x = torch.cat([x_ir, x_vi], dim=1)  # [B,2C,H,W]
        x = self.dw(x)
        x = self.bn(x)
        x = self.act(x)

        if self.use_se:
            s = self.se_gap(x)
            s = self.act(self.se_fc1(s))
            s = self.se_fc2(s)
            x = x * torch.sigmoid(s)

        w = self.sig(self.pw(x))            # [B,out_ch,H,W]
        if w.shape[1] == 1:
            w = w.expand_as(x_ir)           # 广播到逐通道
        return w

    def forward(self, x_vi: torch.Tensor, x_ir: torch.Tensor, *, return_w: bool = False):
        """
        x_vi, x_ir: [B,C,H,W]
        return:
            fused 或 (fused, w)
        """
        w = self._attn_weight(x_ir, x_vi)
        fused = w * x_ir + (1.0 - w) * x_vi
        # 细化（带可学习缩放）
        fused = fused + self.gamma * self.refine(fused)
        return (fused, w) if return_w else fused
