import yaml
from os import path
from dataclasses import dataclass
from typing import Optional, Tuple, Iterator, Dict, List
from importlib import import_module

import torch
from torch.nn import Parameter, Module
from torch.utils.data import DataLoader, ConcatDataset

from dataset import VIFDataset, read_and_split, ImageLabels

# -----------------------------
# 配置对象
# -----------------------------
class ModelConfig:
    def __init__(self, target: str, params: dict, pretrained: Optional[str]=None) -> None:
        self.target: str = target
        self.params = {}
        for k, v in params.items():
            if self.check(v):
                self.params[k] = ModelConfig(**v)
            else:
                self.params[k] = v
        self.pretrained: Optional[str] = pretrained

    @staticmethod
    def check(param: dict) -> bool:
        return isinstance(param, dict) and {'target', 'params'}.issubset(param.keys())

    def __repr__(self) -> str:
        cls = self.__class__.__name__
        return f'{cls}(target={self.target}, params={self.params}, pretrained={self.pretrained})'

class TrainArgs:
    def __init__(self,
        epochs: int,
        accumulation_steps: int,
        optimizer: dict,
    ) -> None:
        self.epochs = epochs
        self.accumulation_steps = accumulation_steps
        self.optimizer = ModelConfig(**optimizer)
    def __repr__(self) -> str:
        return '\n'.join([
            'TrainArgs(',
            f'epochs={self.epochs}',
            f'accumulation_steps={self.accumulation_steps}',
            f'optimizer={self.optimizer}'
        ])

@dataclass
class DatasetArgs:
    """
    url: { "MSRS": "...", "Road": "...", "TNO": "..." }
    ratio: (train, valid) 或 (train, valid, test)
    """
    url: Dict[str, str]
    batch_size: int
    shuffle: bool
    ratio: Optional[Tuple[float, float] | Tuple[float, float, float]] = None
    num_workers: int = 4
    pin_memory: bool = True
    drop_last: bool = False

@dataclass
class TrainConfig:
    model: ModelConfig
    train: TrainArgs
    dataset: DatasetArgs


# -----------------------------
# 加载配置
# -----------------------------
def load_config(file: str='/home/raytrack/Fusion/CMfused11/config/model.yaml') -> TrainConfig:
    config_path = path.abspath(file)
    print(f"使用的配置文件路径: {config_path}")
    assert path.isfile(file), f"配置文件不存在: {file}"
    with open(file) as f:
        config = yaml.full_load(f)
    model = ModelConfig(**config['model'])
    train = TrainArgs(**config['train'])
    dataset = DatasetArgs(**config['dataset'])
    return TrainConfig(model=model, train=train, dataset=dataset)


# -----------------------------
# 动态创建模型
# -----------------------------
def load_model(config: ModelConfig, device: torch.device):
    kwargs = {}
    module_name, cls_name = config.target.rsplit('.', 1)
    print(f"[Model] {module_name}.{cls_name}")
    module = import_module(module_name)
    cls = getattr(module, cls_name)

    # 递归构造子模块
    for k, v in config.params.items():
        kwargs[k] = load_model(v, device) if isinstance(v, ModelConfig) else v

    model: Module = cls(**kwargs)
    if config.pretrained and path.isfile(config.pretrained) and hasattr(model, 'load_state_dict'):
        print(f'Loading pretrained weights from {config.pretrained}')
        state_dict = torch.load(config.pretrained, map_location='cpu')
        model.load_state_dict(state_dict, strict=False)
    return model.to(device)


# -----------------------------
# 加载数据集（支持 MSRS / Road / TNO）
# -----------------------------
def load_dataset(config: DatasetArgs):
    """
    返回：
      - 仅训练集时: [train_loader]
      - 含验证集时: [train_loader, valid_loader]
    """
    # 允许的键：你可以在 YAML 里填任意组合，未提供的会被忽略
    supported_keys = ['MSRS', 'Road', 'TNO']

    # 统一的划分比例：未提供则默认 (0.8, 0.2)
    ratios = config.ratio if config.ratio is not None else (0.8, 0.2)

    train_dsets: List[torch.utils.data.Dataset] = []
    valid_dsets: List[torch.utils.data.Dataset] = []

    for key in supported_keys:
        root = config.url.get(key, None)
        if not root:
            continue
        print(f"[Dataset] Loading {key} from {root} with ratios={ratios}")

        # read_and_split 应该能根据 ratios 返回 ImageLabels(train, valid, test?)
        labels: ImageLabels = read_and_split(root, ratios=ratios)

        # 训练集
        if labels.train:
            train_dsets.append(VIFDataset(labels.train))

        # 验证集（如果没有 valid，read_and_split 可能返回 None）
        if getattr(labels, 'valid', None):
            valid_dsets.append(VIFDataset(labels.valid))

        # 你也可以按需处理 test：
        # if getattr(labels, 'test', None):
        #     test_dsets.append(VIFDataset(labels.test))

    assert len(train_dsets) > 0, "没有可用的训练数据集，请检查 dataset.url 配置路径是否正确。"

    # 组装 DataLoader
    train_loader = DataLoader(
        ConcatDataset(train_dsets) if len(train_dsets) > 1 else train_dsets[0],
        batch_size=config.batch_size,
        shuffle=config.shuffle,
        num_workers=config.num_workers,
        pin_memory=config.pin_memory,
        drop_last=config.drop_last,
    )

    if len(valid_dsets) > 0:
        valid_loader = DataLoader(
            ConcatDataset(valid_dsets) if len(valid_dsets) > 1 else valid_dsets[0],
            batch_size=config.batch_size,
            shuffle=False,
            num_workers=max(1, config.num_workers // 2),
            pin_memory=config.pin_memory,
            drop_last=False,
        )
        return [train_loader, valid_loader]

    return [train_loader]


# -----------------------------
# 优化器
# -----------------------------
def load_optimizer(config: ModelConfig, params: Iterator[Parameter]):
    module_name, cls_name = config.target.rsplit('.', 1)
    module = import_module(module_name)
    optim = getattr(module, cls_name)
    return optim(params, **config.params)
