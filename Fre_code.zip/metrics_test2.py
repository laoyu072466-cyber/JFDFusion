import os
import torch
import pandas as pd
from metric import read_image, calc

# 设置输入文件夹路径
ir_folder = "/root/autodl-tmp/data/traindata/PETMRI/ir"
vis_folder = "/root/autodl-tmp/data/traindata/PETMRI/vi"
fuse_folder = "/root/autodl-tmp/data/testdata/PETMRI-Test/new1"

# 结果保存的路径
results_path = "/root/autodl-tmp/data/testdata/PETMRI_prefuse.xlsx"

# 如果结果文件存在，删除它以便重新创建一个新的
if os.path.exists(results_path):
    os.remove(results_path)

# 获取文件夹中的图像文件列表
ir_files = sorted(os.listdir(ir_folder))
vis_files = sorted(os.listdir(vis_folder))
fuse_files = sorted(os.listdir(fuse_folder))

# 检查文件数量是否一致
assert len(ir_files) == len(vis_files) == len(fuse_files), "IR, VIS, and FUSE folder must have the same number of files"

# 初始化一个字典，用于保存结果
metrics_results = {
    'filename': [],
    'SF': [],
    'EN': [],
    'AG': [],
    'SD': [],
    'CE': [],
    'CC': [],
    'SCD': [],
    'MSE': [],
    'MI': [],
    'PSNR': [],
    'Qabf': [],
    'VIF': [],
    'MS-SSIM': []
}

# 遍历文件夹中的每个图像并计算质量指标
for ir_file, vis_file, fuse_file in zip(ir_files, vis_files, fuse_files):
    ir_path = os.path.join(ir_folder, ir_file)
    vis_path = os.path.join(vis_folder, vis_file)
    fuse_path = os.path.join(fuse_folder, fuse_file)
    
    # 读取图像
    ir = read_image(ir_path)
    vis = read_image(vis_path)
    fuse = read_image(fuse_path)

    # 检查图像形状是否一致
    assert ir.shape == vis.shape == fuse.shape, f"Image shapes do not match for files: {ir_file}, {vis_file}, {fuse_file}"

    # 计算质量评估指标
    metrics = calc(vis, ir, fuse)
    
    # 保存结果
    metrics_results['filename'].append(ir_file)
    for key, value in metrics.items():
        metrics_results[key].append(value)

    print(f"Processed {ir_file}")

# 将结果保存为 Excel 文件
df = pd.DataFrame(metrics_results)
df.to_excel(results_path, index=False)

print(f"Results saved to {results_path}")
